<footer class="footer">
    <div class="container-fluid">
        <p class="copyright pull-right">
            &copy;
            <script>
                document.write(new Date().getFullYear())
            </script>
            Design by <a href="https://twitter.com/JuisDev ">JuisDev</a>, and Developed by <a href="https://github.com/israelnojr">Iloba Israel</a>
        </p>
    </div>
</footer><?php /**PATH C:\xampp\htdocs\globalfastworld\resources\views/layouts/partial/footer.blade.php ENDPATH**/ ?>