<div class="sidebar" data-color="blue" data-image="<?php echo e(asset('backend/img/sidebar-1.jpg')); ?>">

    <div class="logo">
        <a href="<?php echo e(route('dashboard')); ?>" class="simple-text">
           <?php echo $__env->yieldContent('title'); ?>
        </a>
    </div>
    <div class="sidebar-wrapper">
        <ul class="nav">
            <li class="<?php echo e(Request::is('admin/dashboard*')?'active': ''); ?>">
                <a href="<?php echo e(route('dashboard')); ?>">
                    <i class="material-icons">dashboard</i>
                    <p>Dashboard</p>
                </a>
            </li>
            <li class=" <?php echo e(Request::is('admin/slider*')?'active': ''); ?> ">
                <a href=" <?php echo e(route('slider.index')); ?> ">
                    <i class="material-icons">slideshow</i>
                    <p>Sliders</p>
                </a>
            </li>
            <li class="<?php echo e(Request::is('admin/category*')?'active': ''); ?> ">
                <a href="<?php echo e(route('category.index')); ?>">
                    <i class="material-icons">content_paste</i>
                    <p>Categories</p>
                </a>
            </li>
            <li class="<?php echo e(Request::is('admin/product*')?'active': ''); ?>">
                <a href="<?php echo e(route('product.index')); ?>">
                    <i class="material-icons">library_books</i>
                    <p>Products</p>
                </a>
            </li>

            <li class="<?php echo e(Request::is('admin/event*')?'active': ''); ?>">
                <a href="<?php echo e(route('event.index')); ?>">
                    <i class="material-icons">event_seat</i>
                    <p>Events</p>
                </a>
            </li>

            <li class="<?php echo e(Request::is('admin/quotation*')?'active': ''); ?>">
                <a href="<?php echo e(route('quotation.index')); ?>">
                    <i class="material-icons">local_printshop</i>
                    <p>Quotation</p>
                </a>
            </li>


            <li class="<?php echo e(Request::is('admin/project*')?'active': ''); ?>">
                <a href="<?php echo e(route('project.index')); ?>">
                    <i class="material-icons">work_outline</i>
                    <p>Projects</p>
                </a>
            </li>
            
            <li class="<?php echo e(Request::is('admin/contact*') ? 'active': ''); ?>">
                <a href="<?php echo e(route('contact.index')); ?>">
                    <i class="material-icons">message</i>
                    <p>Message</p>
                </a>
            </li>

            <li class="<?php echo e(Request::is('admin/partner*')?'active': ''); ?>">
                <a href="<?php echo e(route('partner.index')); ?>">
                    <i class="material-icons">person_tie</i>
                    <p>Partners</p>
                </a>
            </li>

            <li class="<?php echo e(Request::is('admin/about*')?'active': ''); ?>">
                <a href="<?php echo e(route('about.index')); ?>">
                    <i class="material-icons">info_variant</i>
                    <p>About Us</p>
                </a>
            </li>

        </ul>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\globalfastworld\resources\views/layouts/partial/sidebar.blade.php ENDPATH**/ ?>