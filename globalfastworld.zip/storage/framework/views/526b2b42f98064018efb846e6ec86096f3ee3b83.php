<?php $__env->startSection('title','quotation'); ?>

<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header" data-background-color="purple">
                            <h4 class="title"><?php echo e($quotation->product->name); ?></h4>
                        </div>
                        <div class="card-content">
                           <div class="row">
                               <div class="col-md-12">
                                   <strong>Name: <?php echo e($quotation->fullname); ?></strong><br>
                                   <b>Email: <?php echo e($quotation->email); ?></b> <br>
                                   <b>Phone: <?php echo e($quotation->phone); ?></b> <br>
                                   <b>Address: <?php echo e($quotation->address); ?></b> <br>
                                   <b>Country: <?php echo e($quotation->country); ?></b> <br>
                                   <strong>Message: </strong><hr>

                                   <p><?php echo e($quotation->message); ?></p><hr>

                               </div>
                           </div>
                            <a href="<?php echo e(route('quotation.index')); ?>" class="btn btn-danger">Back</a>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\globalfastworld\resources\views/admin/quotation/show.blade.php ENDPATH**/ ?>